package kr.ac.mjc.minwoo.myapp.board.dao;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Board {
	private String seq = null;
	private String title = null;
	private String content = null;
	private String regdate = null;
	private String writer = null;
	private int cnt = 0;	
}
