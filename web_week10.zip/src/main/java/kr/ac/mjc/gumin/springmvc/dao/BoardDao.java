package kr.ac.mjc.gumin.springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import kr.ac.mjc.gumin.springmvc.domain.Board;
import kr.ac.mjc.gumin.springmvc.domain.Criteria;

@Component
public class BoardDao {

	private final String LIST_BOARDS = "select seq, title, left(regdate,16) regdate, writer, cnt from board order by seq desc limit ?,?";
	private final String GET_BOARD = "select seq, title,content, left(regdate,16) regdate, writer, cnt from board where seq=?";
	private final String ADD_BOARD = "insert board(title, content, writer) values(:title, :content, :writer)";
	private final String UPDATE_BOARD = "update board set title=:title, content=:content where seq=:seq";
	private final String DELETE_BOARD = "delete from board where seq=?";
	private final String GET_TOTAL="select count(*) from board where seq>0";
	
	private final RowMapper<Board> BOARD_ROW_MAPPER = new BeanPropertyRowMapper<Board>(Board.class);
	

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	//전체 게시글의 수를 조회
	public Integer getTotal() {
		return jdbcTemplate.queryForObject(this.GET_TOTAL, Integer.class);
	}
	

	/**
	 * 게시글 목록 조회
	 * 
	 * @param page  페이지
	 * @param count 갯수
	 */
	public List<Board> listBoards(/* int count, int page */ Criteria cri) {
		
		int offset = (cri.getPage() - 1) * cri.getCount(); // 목록 가져올 시작점
		int count = cri.getCount();
		
		return jdbcTemplate.query(LIST_BOARDS, BOARD_ROW_MAPPER, offset, count);
		
		/*
		 * return dbUtils.list(LIST_BOARDS, (rs) -> { Board board = new Board();
		 * board.setSeq(rs.getString("seq")); board.setTitle(rs.getString("title"));
		 * board.setRegdate(rs.getString("regdate"));
		 * board.setWriter(rs.getString("writer")); board.setCnt(rs.getInt("cnt"));
		 * return board; }, offset, cri.getCount());
		 */
	}

	/**
	 * 게시글 1개 조회
	 */
	public Board getBoard(String seq) {
		
		return jdbcTemplate.queryForObject(GET_BOARD, BOARD_ROW_MAPPER, seq);
		
		/*
		 * return dbUtils.get(this.GET_BOARD, (rs) -> { Board board = new Board();
		 * board.setSeq(rs.getString("seq")); board.setTitle(rs.getString("title"));
		 * board.setContent(rs.getString("content"));
		 * board.setRegdate(rs.getString("regdate"));
		 * board.setWriter(rs.getString("writer")); board.setCnt(rs.getInt("cnt"));
		 * return board; }, seq);
		 */
	}

	/**
	 * 게시글 추가
	 */
	public int addBoard(Board board) {
		
		SqlParameterSource params = new BeanPropertySqlParameterSource(board);
		
		return namedParameterJdbcTemplate.update(ADD_BOARD, params);
		
		/*
		 * return dbUtils.update(ADD_BOARD, board.getTitle(), board.getContent(),
		 * board.getWriter());
		 */
	}

	/**
	 * 게시글 수정
	 */
	public int updateBoard(Board board) {
		
		SqlParameterSource params = new BeanPropertySqlParameterSource(board);
		return namedParameterJdbcTemplate.update(UPDATE_BOARD, params);
		
		/*
		 * return dbUtils.update(UPDATE_BOARD, board.getTitle(), board.getContent(),
		 * board.getSeq());
		 */
	}

	/**
	 * 게시글 삭제
	 */
	public int deleteBoard(String seq) {
		
		return jdbcTemplate.update(DELETE_BOARD, seq);
		
		/* return dbUtils.update(DELETE_BOARD, seq); */
	}
}
