package kr.ac.mjc.gumin.springmvc.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.mjc.gumin.springmvc.dao.BoardDao;
import kr.ac.mjc.gumin.springmvc.domain.Board;
import kr.ac.mjc.gumin.springmvc.domain.Criteria;
import kr.ac.mjc.gumin.springmvc.domain.PageDTO;



@Controller
public class BoardController {

	@Autowired
	private BoardDao boardDao;
	
	Logger logger = LogManager.getLogger();
	

	// 목록 화면
	@RequestMapping(value = "/board/boardList", method = RequestMethod.GET)
	public void boardList(Criteria cri, Model model) {
		
		 
		 //page 값과 count 값이 있으면 세팅
		//총 게시글의 수를 가져옴
		int total = boardDao.getTotal();
			
		List<Board> boardList = boardDao.listBoards(cri);
	
		model.addAttribute("boardList", boardList);
		model.addAttribute("pageMaker", new PageDTO(cri, total));
		
	}
	
	//조회 화면
	@RequestMapping(value="/board/boardInfo", method= RequestMethod.GET)
	public void boardInfo(String seq, Criteria cri, Model model) {
		
		Board board=boardDao.getBoard(seq);
	
		model.addAttribute("board", board);
		model.addAttribute("cri", cri);
		
	}
	
	//수정 화면
	@RequestMapping(value="/board/boardEdit", method=RequestMethod.GET)
	public void boardEdit(String seq, Criteria cri, Model model) {
		
		Board board=boardDao.getBoard(seq);
		
		model.addAttribute("board", board);
		model.addAttribute("cri", cri);
	}
	
	//추가 액션
	@RequestMapping(value = "/board/addBoard", method = RequestMethod.POST)
	public String addStudent(Board board, Model model) {

		boardDao.addBoard(board);
		
		return "redirect:/app/board/boardList";
		/*redirect(request, response, "/app/board/boardList");*/
	}
	
	//수정 액션
	@RequestMapping(value = "/board/updateBoard", method = RequestMethod.POST)
	public String updateStudent(Board board, Criteria cri, Model model) {
		
		String seq = board.getSeq();
		
		model.addAttribute("seq", seq);
		model.addAttribute("page",cri.getPage());
		model.addAttribute("count",cri.getCount());
	
		boardDao.updateBoard(board);
		
		return "redirect:/app/board/boardInfo";
		/*
		 * redirect(request, response, "/app/board/boardInfo?seq=" +
		 * seq+"&page="+page+"&count="+count);
		 */
	}
	
	//삭제 액션
	@RequestMapping(value = "/board/deleteBoard", method = RequestMethod.GET)
	public String deleteStudent(String seq) {

		boardDao.deleteBoard(seq);
		
		return "redirect:/app/board/boardList";
		/* redirect(request, response, "/app/board/boardList"); */
	}

}
