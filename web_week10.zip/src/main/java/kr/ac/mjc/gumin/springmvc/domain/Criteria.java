package kr.ac.mjc.gumin.springmvc.domain;
//페이징 처리를 위한 Criteria class

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Criteria {
	private int page=1;
	private int count=10;
	
	public Criteria() {
		this(1,10);
	}
	
	public Criteria(int page, int count) {
		this.page=page;
		this.count=count;
	}

}
