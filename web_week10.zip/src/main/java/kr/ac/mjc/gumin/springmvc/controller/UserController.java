package kr.ac.mjc.gumin.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.ac.mjc.gumin.springmvc.dao.UserDao;
import kr.ac.mjc.gumin.springmvc.domain.User;

@Controller
public class UserController {
	
	@Autowired
	private UserDao userDao;
	
	Logger logger = LogManager.getLogger();
	
	/*
	 * Default Mapping
	 * */
	@GetMapping("/**")
	public void mapDefault(HttpServletRequest request) {
		logger.debug("Default mapping : {}", request.getPathInfo());
	}

	/*
	 * 회원 목록 조회
	 * */
	@GetMapping("/user/userList")
	public void userList(
			@RequestParam(name = "count", required = false, defaultValue = "10") int count,
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			Model model) {
		
		int offset = (page-1);
		List<User> userList = userDao.listUsers(offset, count);
		model.addAttribute("userList", userList);
	}
	
	/*
	 * 회원가입
	 * */
	@PostMapping("/user/join")
	public String join(User user, String confirmPassword, RedirectAttributes redirectAttributes) {
		redirectAttributes.addFlashAttribute("user", user);
		
		try {
			
			if(!user.getPassword().equals(confirmPassword)) {
				logger.debug("User register success!");
				
				return "redirect:/app/user/joinForm?mode=PW_MISMATCH";
			}
			userDao.addUser(user);
			logger.debug("User register success!");
			
			return "redirect:/app/user/joinComplete";
		}catch (DuplicateKeyException e) {
			logger.debug("Email is duplicate!");
			return "redirect:/app/user/joinForm?mode=ERROR";
		}
	}
	
	/*
	 * 로그인
	 * */
	@PostMapping("/login")
	public String login(String email, String password, HttpSession session, RedirectAttributes redirectAttributes) {
		
		try {
			User user = userDao.getUserByEmailAndPassword(email, password);
			logger.debug("Login success!");
			
			session.setAttribute("user", user);
			return "redirect:/app/user/s/userInfo?mode=LOGIN";
		}catch (EmptyResultDataAccessException e) {
			logger.debug("Login fail...");
			redirectAttributes.addFlashAttribute("email", email);
			return "redirect:/app/user/loginForm?mode=ERROR";
		}
	}
	
	/*
	 * 로그아웃
	 * */
	@GetMapping("/s/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
}





























