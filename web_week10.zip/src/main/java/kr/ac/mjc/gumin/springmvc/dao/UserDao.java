package kr.ac.mjc.gumin.springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import kr.ac.mjc.gumin.springmvc.domain.User;

@Component
public class UserDao {

	private final String LIST_UESRS = "select id, email, password, name from user order by id desc limit ?,?;";
	private final String GET_USER = "select id, email, password, name from user where id=?";

	// private final String ADD_USER = "insert into user (email, password, name)
	// values(?,sha2(?,256),?)";
	// private final String UPDATE_USER = "update user set email=?,
	// password=sha2(?,256), name=? where id=?";
	// NamedParameterJdbcTemplate 를 사용한 sql문 수정
	private final String ADD_USER = "insert into user (email, password, name) values(:email,sha2(:password,256),:name)";
	private final String UPDATE_USER = "update user set email=:email, password=sha2(:password,256), name=:name where id=:id";

	// 이메일, 비밀번호로 조회 (로그인 할 때 사용)
	private final String GET_USER_BY_EMAIL_PASSWORD = "select id, email, name from user where (email, password) = (?, sha2(?,256))";
	// 비밀번호 수정
	private final String UPDATE_PASSWORD = "update user set password=sha2(?,256) where (id, password) = (?, sha2(?,256))";

	private final String DELETE_USER = "delete from user where id=?";

	private final RowMapper<User> USER_ROW_MAPPER = new BeanPropertyRowMapper<User>(User.class); // 이름에 따라서 매핑

	@Autowired
//	private DbUtils dbUtils;
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	/*
	 * 게시글 목록 조회
	 * 
	 * @param page 페이지
	 * 
	 * @param count 갯수
	 */

	public List<User> listUsers(int offset, int count) {

		/*
		 * return jdbcTemplate.query(LIST_UESRS, (rs, rowNum)->{ // TODO Auto-generated
		 * method stub User user = new User(); user.setId(rs.getString("id"));
		 * user.setEmail(rs.getString("email"));
		 * user.setPassword(rs.getString("password"));
		 * user.setName(rs.getString("name")); return user; },offset, count);
		 */

		return jdbcTemplate.query(LIST_UESRS, USER_ROW_MAPPER, offset, count);
	}

	/*
	 * 게시글 1개 조회
	 */
	public User getUser(String id) {
		/*
		 * return jdbcTemplate.queryForObject(this.GET_USER, (rs, rowNum) -> { User
		 * user= new User(); user.setId(rs.getString("id"));
		 * user.setEmail(rs.getString("email"));
		 * user.setPassword(rs.getString("password"));
		 * user.setName(rs.getString("name")); return user; }, id);
		 */

		return jdbcTemplate.queryForObject(GET_USER, USER_ROW_MAPPER, id);
	}

	/**
	 * 게시글 추가
	 */
	public int addUser(User user) {
		// return jdbcTemplate.update(ADD_USER, user.getEmail(), user.getPassword(),
		// user.getName());
		SqlParameterSource params = new BeanPropertySqlParameterSource(user);
		return namedParameterJdbcTemplate.update(ADD_USER, params);
	}

	/**
	 * 게시글 수정
	 */
	public int updateUser(User user) {
		// return jdbcTemplate.update(UPDATE_USER, user.getEmail(), user.getPassword(),
		// user.getName(), user.getId());
		SqlParameterSource params = new BeanPropertySqlParameterSource(user);
		// public int update(String sql, SqlParameterSource paramSource)
		return namedParameterJdbcTemplate.update(UPDATE_USER, params);
	}

	/**
	 * 게시글 삭제
	 */
	public int deleteUser(String id) {
		return jdbcTemplate.update(DELETE_USER, id);
	}
	
	/*
	 * user email,password로 조회
	 * */
	public User getUserByEmailAndPassword(String email, String password) {
		
		return jdbcTemplate.queryForObject(GET_USER_BY_EMAIL_PASSWORD, USER_ROW_MAPPER ,email, password);
	}
	
	/*
	 * user password  변경
	 * */
	public int updatePassword(String newPassword, String id, String oldPassword) {
		
		return jdbcTemplate.update(UPDATE_PASSWORD, USER_ROW_MAPPER, newPassword, id, oldPassword);
	}

}
