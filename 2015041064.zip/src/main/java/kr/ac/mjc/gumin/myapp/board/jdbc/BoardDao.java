package kr.ac.mjc.gumin.myapp.board.jdbc;

import java.util.List;

import javax.sql.DataSource;

import org.mariadb.jdbc.MariaDbDataSource;

import kr.ac.mjc.gumin.myapp.board.domain.BoardDTO;
import kr.ac.mjc.gumin.myapp.board.domain.Criteria;
import kr.ac.mjc.gumin.myapp.common.dao.DbUtils;

public class BoardDao {

	private final String LIST_BOARDS = "select seq, title, left(regdate,16) regdate, writer, cnt from board order by seq desc limit ?,?";
	private final String GET_BOARD = "select seq, title,content, left(regdate,16) regdate, writer, cnt from board where seq=?";
	private final String ADD_BOARD = "insert board(title, content, writer) values(?,?,?)";
	private final String UPDATE_BOARD = "update board set title=?, content=? where seq=?";
	private final String DELETE_BOARD = "delete from board where seq=?";
	private final String GET_TOTAL="select count(*) from board where seq>0";

	private DbUtils dbUtils = null;

	public BoardDao() {
		DataSource ds = new MariaDbDataSource(
				"jdbc:mariadb://irafe.com:3306/jdbc?user=jdbc&password=javaprogramming");
		this.dbUtils = new DbUtils(ds);
	}
	
	//전체 게시글의 수를 조회
	public String getTotal() {
		return dbUtils.get(this.GET_TOTAL, (rs)->{
			String totalCount=rs.getString("count(*)");
			return totalCount;
		});
	}
	

	/**
	 * 게시글 목록 조회
	 * 
	 * @param page  페이지
	 * @param count 갯수
	 */
	public List<BoardDTO> listBoards(/* int count, int page */ Criteria cri) {
		int offset = (cri.getPage() - 1) * cri.getCount(); // 목록 가져올 시작점
		return dbUtils.list(LIST_BOARDS, (rs) -> {
			BoardDTO board = new BoardDTO();
			board.setSeq(rs.getString("seq"));
			board.setTitle(rs.getString("title"));
			board.setRegdate(rs.getString("regdate"));
			board.setWriter(rs.getString("writer"));
			board.setCnt(rs.getInt("cnt"));
			return board;
		}, offset, cri.getCount());
	}

	/**
	 * 게시글 1개 조회
	 */
	public BoardDTO getBoard(String seq) {
		return dbUtils.get(this.GET_BOARD, (rs) -> {
			BoardDTO board = new BoardDTO();
			board.setSeq(rs.getString("seq"));
			board.setTitle(rs.getString("title"));
			board.setContent(rs.getString("content"));
			board.setRegdate(rs.getString("regdate"));
			board.setWriter(rs.getString("writer"));
			board.setCnt(rs.getInt("cnt"));
			return board;
		}, seq);
	}

	/**
	 * 게시글 추가
	 */
	public int addBoard(BoardDTO board) {
		return dbUtils.update(ADD_BOARD, board.getTitle(), board.getContent(),
				board.getWriter());
	}

	/**
	 * 게시글 수정
	 */
	public int updateBoard(BoardDTO board) {
		return dbUtils.update(UPDATE_BOARD, board.getTitle(),
				board.getContent(), board.getSeq());
	}

	/**
	 * 게시글 삭제
	 */
	public int deleteBoard(String seq) {
		return dbUtils.update(DELETE_BOARD, seq);
	}
}
