package kr.ac.mjc.gumin.myapp.common.mvc;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RequestMapping {

	public enum RequestMethod {
		GET, POST
	}

	String value();

	RequestMethod method();
}
