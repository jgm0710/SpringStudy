package kr.ac.mjc.gumin.myapp.board.mvc;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.ac.mjc.gumin.myapp.board.domain.BoardDTO;
import kr.ac.mjc.gumin.myapp.board.domain.Criteria;
import kr.ac.mjc.gumin.myapp.board.domain.PageDTO;
import kr.ac.mjc.gumin.myapp.board.jdbc.BoardDao;
import kr.ac.mjc.gumin.myapp.common.mvc.Controller;
import kr.ac.mjc.gumin.myapp.common.mvc.ControllerException;
import kr.ac.mjc.gumin.myapp.common.mvc.RequestMapping;
import kr.ac.mjc.gumin.myapp.common.mvc.RequestMapping.RequestMethod;

@Controller
public class BoardController {

	BoardDao boardDao = null;

	public BoardController() {
		boardDao = new BoardDao();
	}
	

	// 목록 화면
	@RequestMapping(value = "/board/boardList", method = RequestMethod.GET)
	public void boardList(HttpServletRequest request, HttpServletResponse response) {
		
		 
		 //page 값과 count 값이 있으면 세팅
		Criteria cri = new Criteria();	
		if(request.getParameter("page")!=null) {
			 int page=Integer.parseInt(request.getParameter("page")); 
			 cri.setPage(page);
		}
		if(request.getParameter("count")!=null) {
			 int count=Integer.parseInt(request.getParameter("count")); 
			 cri.setCount(count);
		}
		//총 게시글의 수를 가져옴
		int total = Integer.parseInt(boardDao.getTotal());
			
		List<BoardDTO> boardList = boardDao.listBoards(cri);
		//requst에 total값과 한페이지에 해당하는 리스트를 담아서 view에 보냄
		request.setAttribute("boardList", boardList);
		request.setAttribute("pageMaker", new PageDTO(cri, total));
		this.forward(request, response, "board/boardList.jsp");
	}
	
	//조회 화면
	@RequestMapping(value="/board/boardInfo", method= RequestMethod.GET)
	public void boardInfo(HttpServletRequest request, HttpServletResponse response) {
		String seq =request.getParameter("seq");
		BoardDTO board=boardDao.getBoard(seq);
		request.setAttribute("board", board);
		this.forward(request, response, "board/boardInfo.jsp");
	}
	
	//수정 화면
	@RequestMapping(value="/board/boardEdit", method=RequestMethod.GET)
	public void boardEdit(HttpServletRequest request, HttpServletResponse response) {
		String seq= request.getParameter("seq");
		BoardDTO board=boardDao.getBoard(seq);
		request.setAttribute("board", board);
		this.forward(request, response, "board/boardEdit.jsp");
	}
	
	//추가 액션
	@RequestMapping(value = "/board/addBoard", method = RequestMethod.POST)
	public void addStudent(HttpServletRequest request,
			HttpServletResponse response) {

		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String writer = request.getParameter("writer");

		BoardDTO board = new BoardDTO(null, title, content, null, writer, 0);
		boardDao.addBoard(board);
		redirect(request, response, "/app/board/boardList");
	}
	
	//수정 액션
	@RequestMapping(value = "/board/updateBoard", method = RequestMethod.POST)
	public void updateStudent(HttpServletRequest request,
			HttpServletResponse response) {

		String seq = request.getParameter("seq");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String writer = request.getParameter("writer");
		
		String page = request.getParameter("page");
		String count = request.getParameter("count");
		

		BoardDTO board = new BoardDTO(seq, title, content, null, writer, 0);
		boardDao.updateBoard(board);
		redirect(request, response, "/app/board/boardInfo?seq=" + seq+"&page="+page+"&count="+count);
	}
	
	//삭제 액션
	@RequestMapping(value = "/board/deleteBoard", method = RequestMethod.GET)
	public void deleteStudent(HttpServletRequest request,
			HttpServletResponse response) {

		String seq = request.getParameter("seq");
		boardDao.deleteBoard(seq);
		redirect(request, response, "/app/board/boardList");
	}
	

	/**
	 * forward
	 */
	private void forward(HttpServletRequest request, HttpServletResponse response, String jsp) {
		try {
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/" + jsp).forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
			throw new ControllerException(e);
		}
	}

	/**
	 * redirect
	 */
	private void redirect(HttpServletRequest request, HttpServletResponse response, String url) {
		try {
			response.sendRedirect(request.getContextPath() + url);
		} catch (IOException e) {
			e.printStackTrace();
			throw new ControllerException(e);
		}
	}

}
