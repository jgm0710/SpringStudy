package kr.ac.mjc.gumin.springmvc.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.ac.mjc.gumin.springmvc.dao.StoryDao;
import kr.ac.mjc.gumin.springmvc.domain.Story;

@Controller
public class StoryController {
	
	@Autowired
	private StoryDao storyDao;
	
	private final Logger logger = LogManager.getLogger();
	
	@GetMapping("/story/storyList")
	public void storyList(
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "count", required = false, defaultValue = "10") int count,
			Model model) {
		
		List<Story> storyList = storyDao.getStoryList(page, count);
		
		model.addAttribute("storyList", storyList);
		
	}
	
	@PostMapping("/story/addStory")
	public String addStory(Story story, Model model) {
		
		storyDao.addStory(story);
		
		return "redirect:/app/story/storyList";
	}
}
