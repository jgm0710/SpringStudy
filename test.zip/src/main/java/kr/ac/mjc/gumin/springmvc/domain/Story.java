package kr.ac.mjc.gumin.springmvc.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Story {

	private String id;
	private String content;
	private String name;
	private String date;
}
