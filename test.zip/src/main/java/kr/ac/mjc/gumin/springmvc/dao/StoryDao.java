package kr.ac.mjc.gumin.springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import kr.ac.mjc.gumin.springmvc.domain.Story;

@Repository
public class StoryDao {
	private final String ADD_STORY="insert into story (content, name) values (?,?)";
	private final String LIST_STORY="select id, content, name, date from story order by id desc limit ?,?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private final RowMapper<Story> STORY_ROW_MAPPER = new BeanPropertyRowMapper<>(Story.class);
	
	public List<Story> getStoryList(int page, int count){
		
		int offset = (page-1)*count;
		
		return jdbcTemplate.query(LIST_STORY, STORY_ROW_MAPPER, offset, count);
	}
	
	public int addStory(Story story) {
		return jdbcTemplate.update(ADD_STORY, story.getContent(), story.getName());
	}
}
