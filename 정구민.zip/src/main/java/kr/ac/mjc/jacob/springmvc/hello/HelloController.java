package kr.ac.mjc.jacob.springmvc.hello;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.ac.mjc.gumin.springmvc.domain.Board;
import kr.ac.mjc.gumin.springmvc.domain.User;

@Controller
public class HelloController {
	
	Logger logger = LogManager.getLogger();

	/**
	 * 리턴 타입이 String일 경우 app-context.xml의 viewResolver에 정의된 prefix와 suffix를 리턴값의
	 * 앞뒤에 붙인 jsp로 forward
	 */
	@GetMapping("/hello") // /app/hello에 매핑됨
	public String hello() {
		return "hello"; // forward "/WEB-INF/jsp/hello.jsp"
	}

	/**
	 * 리턴 타입이 void일 경우 app-context.xml의 viewResolver에 정의된 prefix와 suffix를 매핑된
	 * URL의 앞뒤에 붙인 jsp로 forward
	 */
	@GetMapping("/bonjour") // /app/bonjour에 매핑됨
	public void bonjour() { // forward "/WEB-INF/jsp/bonjour.jsp"
	}
	
	@GetMapping("/ciao")
	public void ciao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String name = request.getParameter("name");
		String greeting = "Ciao," + name;
		
		request.setAttribute("greeting", greeting);
		request.getRequestDispatcher("/WEB-INF/jsp/greeting.jsp").forward(request, response);
	}
	
	@GetMapping("/hola")
	public String hola(@RequestParam("name") String name, Model model) {
		
		String greeting = "Hola," + name;
		model.addAttribute("greeting", greeting);
		
		return "greeting";
	}
	
	@PostMapping("/addBoard")
	public String addBorad(@ModelAttribute("board") Board board, Model model) {
		
		logger.debug("request attribute : {}", board);
		
		User user = new User();
		user.setName("gumin");
		
		model.addAttribute("user", user);
		
		return "result";
	}
}




























