package kr.ac.mjc.gumin.spring.day1.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import kr.ac.mjc.gumin.spring.day1.user.common.DbUtils;

@Component
public class UserDao {

	private final String LIST_UESRS="select id, email, password, name from user order by id desc limit ?,?;";
	private final String GET_USER="select id, email, password, name from user where id=?";
	private final String ADD_USER="insert into user (email, password, name) values(?,sha2(?,256),?)";
	private final String UPDATE_USER="update user set email=?, password=sha2(?,256), name=? where id=?";
	private final String DELETE_USER="delete from user where id=?";
	
	@Autowired
	private DbUtils dbUtils;
	
	/*
	 * 게시글 목록 조회
	 * 
	 * @param page 페이지
	 * 
	 * @param count 갯수
	 */
	
	public List<User> listUsers(int count, int page) {
		int offset = (page - 1) * count; // 목록 가져올 시작점
		return dbUtils.list(LIST_UESRS, (rs) -> {
			User user = new User();
			user.setId(rs.getString("id"));
			user.setEmail(rs.getString("email"));
			user.setPassword(rs.getString("password"));
			user.setName(rs.getString("name"));
			return user;
		}, offset, count);
	}

	/*
		게시글 1개 조회
	*/
	public User getUser(String id) {
		return dbUtils.get(this.GET_USER, (rs) -> {
			User user= new User();
			user.setId(rs.getString("id"));
			user.setEmail(rs.getString("email"));
			user.setPassword(rs.getString("password"));
			user.setName(rs.getString("name"));
			return user;
		}, id);
	}
	
	/**
	 * 게시글 추가
	 */
	public int addUser(User user) {
		return dbUtils.update(ADD_USER, user.getEmail(), user.getPassword(), user.getName());
	}
	
	/**
	 * 게시글 수정
	 */
	public int updateUser(User user) {
		return dbUtils.update(UPDATE_USER, 
				user.getEmail(), user.getPassword(), user.getName(), user.getId());
	}

	/**
	 * 게시글 삭제
	 */
	public int deleteUser(String id) {
		return dbUtils.update(DELETE_USER, id);
	}
	
}
