package kr.ac.mjc.gumin.spring.day1.user;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UpdateUserEx {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		UserDao KserDao = (UserDao) context.getBean("userDao");
		String id = "484";
		User user= new User(id, "jgm0710@mjc.ac.kr", "kkk1234", "정구민2");
		KserDao.updateUser(user);

		user = KserDao.getUser(id);
		System.out.println("수정했습니다.\n" + user);
		context.close();
	}
}
