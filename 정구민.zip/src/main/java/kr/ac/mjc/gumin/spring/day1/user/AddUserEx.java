package kr.ac.mjc.gumin.spring.day1.user;

import java.util.List;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AddUserEx {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		UserDao userDao = (UserDao) context.getBean("userDao");
		User user = new User(null, "jgm0710@mjc.ac.kr", "kkk1234", "정구민");
		userDao.addUser(user);
		System.out.println("게시글을 추가했습니다.");

		List<User> userList = userDao.listUsers(5, 1);// 5개씩, 1 page
		for (User u : userList)
			System.out.println(u);
		context.close();
	}

}
