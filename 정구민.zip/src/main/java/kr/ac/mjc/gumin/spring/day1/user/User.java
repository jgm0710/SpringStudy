package kr.ac.mjc.gumin.spring.day1.user;

import lombok.Data;

import lombok.NoArgsConstructor;

import lombok.AllArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

	String id;
	String email;
	String password;
	String name;
}
