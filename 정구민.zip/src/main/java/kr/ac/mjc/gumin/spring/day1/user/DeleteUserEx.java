package kr.ac.mjc.gumin.spring.day1.user;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DeleteUserEx {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		UserDao userDao = (UserDao) context.getBean("userDao");
		String id="485";
		int updatedRows = userDao.deleteUser(id);
		if (updatedRows > 0)
			System.out.println("삭제했습니다. id=" + id);
		else
			System.out.println("잘못된 USER_ID 입니다. id=" + id);
		context.close();
	}
}
