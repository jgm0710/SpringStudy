package kr.ac.mjc.gumin.springmvc.domain;

import lombok.Data;

@Data
public class Board {

	private String seq;
	private String title;
	private String content;
	private String regdate;
	private String writer;
	private int cnt;
}
