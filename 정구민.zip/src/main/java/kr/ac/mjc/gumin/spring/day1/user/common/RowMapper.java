package kr.ac.mjc.gumin.spring.day1.user.common;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Functional interface
 * 
 * @author Jacob
 */
public interface RowMapper<T> {
	public T mapRow(ResultSet rs) throws SQLException;
}
