package kr.ac.mjc.gumin.spring.day1.user;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GetUserEx {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		UserDao userDao = (UserDao)context.getBean("userDao");
		User user = userDao.getUser("1");
		System.out.println(user);
		context.close();
	}
}
